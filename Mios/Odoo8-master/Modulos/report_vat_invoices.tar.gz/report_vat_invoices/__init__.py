# -*- coding: utf-8 -*-
import report_vat_invoices
# from wizard import update_vat_wizard
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
