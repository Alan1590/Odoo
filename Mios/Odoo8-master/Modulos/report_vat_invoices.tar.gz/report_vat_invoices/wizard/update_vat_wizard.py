# from openerp import models, fields, api
# from openerp.osv import fields, osv

# import logging
# logger = logging.getLogger(__name__)

# class update_vat_wizard(models.Model):
#     """ Print tax from invoice
#     """
#     _name = "update.vat.wizard"
#     _description = "Print tax report"

#     @api.one
#     @api.returns('account.invoice')
#     def button_reset_taxes(self):
#         logger.info(str(self))

#     	return 0
